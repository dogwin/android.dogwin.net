/** Automatically generated file. DO NOT MODIFY */
package dogwin.net.apps;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}